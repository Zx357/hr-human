<template>
  <view class="oa-content">
    <!-- 顶部自定义导航 -->
    <tn-navbar fixed home-icon="" :bottom-shadow="false" bg-color="#FFFFFF" :placeholder="false">
      <view slot="back" class='tn-custom-nav-bar__back'
        @click="goBack">
        <tn-icon name="left-arrow" class='icon'></tn-icon>
      </view>
      <view class="tn-flex tn-flex-col-center tn-flex-row-center ">
        <text class="tn-text-bold tn-text-xl tn-color-black">系统公告</text>
      </view>
    </tn-navbar>
    
    <view class="tn-bg-white top-fixed" :style="{paddingTop: vuex_custom_bar_height + 10 +'px'}">
      <tn-tabs v-model="current" activeColor="#3D7EFF" color="#C5CAD5" bold bgColor="#FFFFFF" fontSize="32">
        <tn-tabs-item
          v-for="(item, index) in fixedList"
          :key="index"
          :title="item.name"
        />
      </tn-tabs>
    </view>
    
    <view class="tn-padding-bottom-xl" :style="{paddingTop: vuex_custom_bar_height + 60 +'px'}">
      <view class="" v-if="current==0">
        <view class="content-bg tn-margin tn-padding" v-for="(item, index) in noticeList" :key="index" @click="tn('')">
          <view class="tn-flex tn-flex-col-center tn-flex-row-left">
            <view class="" :class="['oa-' + item.color]">
              <tn-icon name="circle-fill" class="tn-margin-right-sm tn-text-xl"></tn-icon>
            </view>
            <view class="tn-text-justify clamp-text-1 tn-text-lg tn-text-bold">
              {{ item.title }}
            </view>
          </view>
          <view class="tn-text-justify clamp-text-2 tn-padding-top-sm tn-color-gray--dark">
            {{ item.content }}
          </view>
          <view class="tn-flex tn-flex-direction-row tn-flex-col-center tn-flex-row-between tn-padding-top-sm">
            <view class="tn-flex">
              <view class="tn-flex user-pic">
                <view class="user-image" :style="'background-image:url('+ item.userImage +');width: 35rpx;height: 35rpx;background-size: cover;'">
                </view>
              </view>
              <view class="tn-flex tn-margin-left-xs" style="width: 300rpx;">
                <text class="clamp-text-1 tn-color-gray--dark">{{ item.userName }}</text>
              </view>
            </view>
            <view class="tn-color-gray">
              {{ item.date }}
            </view>
          </view>
          
        </view>
      </view>
      <view class="" v-if="current==1">
        <view class="content-bg tn-margin tn-padding" v-for="(item, index) in noticeList1" :key="index" @click="tn('')">
          <view class="tn-flex tn-flex-col-center tn-flex-row-left">
            <!-- <view class="" :class="['oa-' + item.color]">
              <tn-icon name="circle-fill" class="tn-margin-right-sm tn-text-xl"></tn-icon>
            </view> -->
            <view class="tn-text-justify clamp-text-1 tn-text-lg tn-text-bold">
              {{ item.title }}
            </view>
          </view>
          <view class="tn-text-justify clamp-text-2 tn-padding-top-sm tn-color-gray--dark">
            {{ item.content }}
          </view>
          <view class="tn-flex tn-flex-direction-row tn-flex-col-center tn-flex-row-between tn-padding-top-sm">
            <view class="tn-flex">
              <view class="tn-flex user-pic">
                <view class="user-image" :style="'background-image:url('+ item.userImage +');width: 35rpx;height: 35rpx;background-size: cover;'">
                </view>
              </view>
              <view class="tn-flex tn-margin-left-xs" style="width: 300rpx;">
                <text class="clamp-text-1 tn-color-gray--dark">{{ item.userName }}</text>
              </view>
            </view>
            <view class="tn-color-gray">
              {{ item.date }}
            </view>
          </view>
          
        </view>
      </view>
    </view>    
    

  </view>
</template>

<script setup>
import { ref } from 'vue'
import { useCustomBarHeight, useGoBack } from '@/libs/composables'
// 使用 composable 获取自定义导航栏高度
const { vuex_custom_bar_height } = useCustomBarHeight()
const { goBack } = useGoBack()

const current = ref(0)

const fixedList = ref([
  {name: '未 读'},
  {name: '已 读'}
])

const noticeList = ref([
  {
    color: 'orangered',
    title: '2024年春节放假通知',
    content: '各位同事：一年一度的春节又到啦，根据国家法定节假日规定，2024年春节放假安排如下：02月01日——02月22日',
    userImage: 'https://cdn.nlark.com/yuque/0/2023/jpeg/280373/1692940242423-assets/web-upload/6d82b929-67e4-4919-a826-c931940f5872.jpeg',
    userName: '那只猪-图鸟人事部',
    date: '2024-01-26 10:12',
  }, {
    color: 'blue',
    title: '关于年前请假审批流程通知',
    content: '各位同事：这里是一大堆瞎逼逼的描述，为了凑字数，想不出来什么文案了',
    userImage: 'https://cdn.nlark.com/yuque/0/2023/jpeg/280373/1696519175593-assets/web-upload/b6b5c625-f3ba-4d0a-9506-2dc079a89997.jpeg',
    userName: '你的名字',
    date: '2024-01-20 14:02',
  }, {
    color: 'green',
    title: '图鸟OA系统更新通知',
    content: '各位同事：这里是一大堆瞎逼逼的描述，为了凑字数，想不出来什么文案了',
    userImage: 'https://cdn.nlark.com/yuque/0/2023/jpeg/280373/1694103627542-assets/web-upload/8d373c70-a1cb-4395-86e8-7e499856d45e.jpeg',
    userName: '不许凶我吖',
    date: '2024-01-12 09:56',
  }, {
    color: 'blue',
    title: '凑数的文案，凑够一行超出隐藏，不喜勿喷',
    content: '各位同事：这里是一大堆瞎逼逼的描述，为了凑字数，想不出来什么文案了',
    userImage: 'https://cdn.nlark.com/yuque/0/2023/jpeg/280373/1694103627675-assets/web-upload/7f0fc488-330d-46fa-970e-ef19756ddef4.jpeg',
    userName: '图鸟西西',
    date: '2024-01-06 17:59',
  }, {
    color: 'green',
    title: '2023年12月考勤统计核对表',
    content: '各位同事：这里是一大堆瞎逼逼的描述，为了凑字数，想不出来什么文案了',
    userImage: 'https://cdn.nlark.com/yuque/0/2023/jpeg/280373/1692948628847-assets/web-upload/34ed894b-97ef-4fd0-a1f1-fb7507ce3ac7.jpeg',
    userName: '猪猪打杂',
    date: '2023-12-26 16:26',
  }, {
    color: 'green',
    title: '2023年年度优秀员工表彰大会',
    content: '各位同事：这里是一大堆瞎逼逼的描述，为了凑字数，想不出来什么文案了',
    userImage: 'https://cdn.nlark.com/yuque/0/2023/jpeg/280373/1692940242409-assets/web-upload/fcc4eab6-b2ce-44eb-9165-c49b51f5f830.jpeg',
    userName: '抓住那只猪',
    date: '2023-12-22 12:56',
  }
])

const noticeList1 = ref([
  {
    color: 'blue',
    title: '凑数的文案，不喜勿喷',
    content: '各位同事：这里是一大堆瞎逼逼的描述，为了凑字数，想不出来什么文案了',
    userImage: 'https://cdn.nlark.com/yuque/0/2023/jpeg/280373/1692940242452-assets/web-upload/cfb64a56-9e2c-42ea-bb49-5b9d1b996898.jpeg',
    userName: '图鸟西西',
    date: '2024-01-06 17:59',
  }, {
    color: 'green',
    title: '凶姐到此一游',
    content: '各位同事：这里是一大堆瞎逼逼的描述，为了凑字数，想不出来什么文案了',
    userImage: 'https://cdn.nlark.com/yuque/0/2023/jpeg/280373/1692940242390-assets/web-upload/d4f101d0-29c5-43d2-8519-4ac2e5199726.jpeg',
    userName: '抓住那只猪',
    date: '2023-12-26 16:26',
  }
])

// 跳转
const tn = (e) => {
  uni.navigateTo({
    url: e,
  });
}
</script>

<style lang="scss" scoped>
  /* 胶囊*/
  .tn-custom-nav-bar__back {
    width: 60%;
    height: 100%;
    position: relative;
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    box-sizing: border-box;
    background-color: rgba(0, 0, 0, 0.15);
    border-radius: 1000rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.5);
    color: #FFFFFF;
    font-size: 18px;
    
    .icon {
      display: block;
      flex: 1;
      margin: auto;
      text-align: center;
    }
  }
  
  /* 新增OA色系，自行调用，或者拿色值去用，多种方式*/
  .oa-black{
    color: #1D2541;
  }
  .oa-blue{
    color: #4B98FE;
  }
  .oa-orangeyellow{
    color: #FFAC00;
  }
  .oa-green{
    color: #00D05E;
  }
  .oa-orange{
    color: #FE871B;
  }
  .oa-cyan{
    color: #00C8B0;
  }
  .oa-indigo{
    color: #00B9FE;
  }
  .oa-orangered{
    color: #FB6A67;
  }
  .oa-purple{
    color: #957BFE;
  }
  
  .oa-content{
    max-width: 640px;
    margin: 0 auto;
    background-color: #F8F7F8;
    min-height: 100vh;
    padding-bottom: 60rpx;
    padding-bottom: calc(80rpx + env(safe-area-inset-bottom) / 2);
    padding-bottom: calc(80rpx + constant(safe-area-inset-bottom));
  }
  
  .top-fixed{
    max-width: 640px;
    margin: 0 auto;
    position: fixed;
    background-color: rgba(255,255,255,1);
    top: 0;
    width: 100%;
    transition: all 0.25s ease-out;
    z-index: 100;
  }

  /* 文字截取*/
  .clamp-text-1 {
    -webkit-line-clamp: 1;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  
  .clamp-text-2 {
    -webkit-line-clamp: 2;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    text-overflow: ellipsis;
    overflow: hidden;
  }
  
  /* 背景阴影 start*/
  .content-bg {
    border-radius: 15rpx;
    background-color: #FFFFFF;
    // box-shadow: 0rpx 0rpx 50rpx 0rpx rgba(0, 0, 0, 0.07);
  }
   
   /* 用户头像 start */
   .user-image {
     width: 35rpx;
     height: 35rpx;
     position: relative;
     overflow: hidden;
     border-radius: 50%;
   }
   
   .user-pic {
     background-size: cover;
     background-repeat: no-repeat;
     // background-attachment:fixed;
     background-position: top;
     border: 1rpx solid rgba(255,255,255,0.05);
     box-shadow: 0rpx 0rpx 80rpx 0rpx rgba(0, 0, 0, 0.15);
     border-radius: 50%;
     overflow: hidden;
     // background-color: #FFFFFF;
   }
    
</style>
