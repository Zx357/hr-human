<template>
  <view class="oa-content">
    <!-- 顶部自定义导航 -->
    <tn-navbar fixed home-icon="" :bottom-shadow="false" bg-color="#FFFFFF" :placeholder="false">
      <view slot="back" class='tn-custom-nav-bar__back'
        @click="goBack">
        <tn-icon name="left-arrow" class="icon"></tn-icon>
      </view>
      <view class="tn-flex tn-flex-col-center tn-flex-row-center ">
        <text class="tn-text-bold tn-text-xl tn-color-black">审批详情</text>
      </view>
    </tn-navbar>
    
    
    <view class="p-backgroup" :style="{paddingTop: vuex_custom_bar_height + 10 +'px'}">
      
      <view class="">
        <view class="tn-margin tn-padding-top" style="border-radius: 20rpx;height: 150rpx;background-color: #FFFFFF;">
          <tn-steps :list="list" :current="current1" mode="icon" activeColor="#00D05E" inActiveColor="#AAAAAA" @click="stepItemClick"></tn-steps>
          <view class="" style="background-color: #FFFFFF00;width: 100%;height: 150rpx;position: relative;top: -120rpx;">
          </view>
        </view>
        <view class="tn-margin tn-padding-top" style="border-radius: 20rpx;height: 150rpx;background-color: #FFFFFF;">
          <tn-steps :list="list" :current="current2" mode="icon" activeColor="#00D05E" inActiveColor="#AAAAAA" @click="stepItemClick"></tn-steps>
          <view class="" style="background-color: #FFFFFF00;width: 100%;height: 150rpx;position: relative;top: -120rpx;">
          </view>
        </view>
        <view class="tn-margin tn-padding-top" style="border-radius: 20rpx;height: 150rpx;background-color: #FFFFFF;">
          <tn-steps :list="list" :current="current3" mode="icon" activeColor="#00D05E" inActiveColor="#AAAAAA" @click="stepItemClick"></tn-steps>
          <view class="" style="background-color: #FFFFFF00;width: 100%;height: 150rpx;position: relative;top: -120rpx;">
          </view>
        </view>
        <view class="tn-margin tn-padding-top" style="border-radius: 20rpx;height: 150rpx;background-color: #FFFFFF;">
          <tn-steps :list="list" :current="current4" mode="icon" activeColor="#00D05E" inActiveColor="#AAAAAA" @click="stepItemClick"></tn-steps>
          <view class="" style="background-color: #FFFFFF00;width: 100%;height: 150rpx;position: relative;top: -120rpx;">
          </view>
        </view>
        <view class="tn-margin tn-padding-top" style="border-radius: 20rpx;height: 150rpx;background-color: #FFFFFF;">
          <tn-steps :list="list" :current="current5" mode="icon" activeColor="#00D05E" inActiveColor="#AAAAAA" @click="stepItemClick"></tn-steps>
          <view class="" style="background-color: #FFFFFF00;width: 100%;height: 150rpx;position: relative;top: -120rpx;">
          </view>
        </view>
        
      </view>
    
    </view>
    
    
    <view class="tn-tabbar-height"></view>
    
  </view>
</template>

<script setup>
import { ref } from 'vue'
import { useCustomBarHeight, useGoBack } from '@/libs/composables'
// 使用 composable 获取自定义导航栏高度
const { vuex_custom_bar_height } = useCustomBarHeight()
const { goBack } = useGoBack()

const current1 = ref(1)
const current2 = ref(2)
const current3 = ref(3)
const current4 = ref(4)
const current5 = ref(5)

const list = ref([
  {
    name: '待审批',
    icon: 'time',
    selectIcon: 'time-fill'
  },
  {
    name: '审批中',
    icon: 'light',
    selectIcon: 'light-fill'
  },
  {
    name: '已流转',
    icon: 'safe',
    selectIcon: 'safe-fill'
  },
  {
    name: '审批中',
    icon: 'light',
    selectIcon: 'light-fill'
  },
  {
    name: '已通过',
    icon: 'success-circle',
    selectIcon: 'success-circle-fill'
  }
])

const current = ref(0)

// 跳转
const tn = (e) => {
  uni.navigateTo({
    url: e,
  });
}

const stepItemClick = (e) => {
  current.value = e.index
}
</script>

<style lang="scss" scoped>
  /* 胶囊*/
  .tn-custom-nav-bar__back {
    width: 60%;
    height: 100%;
    position: relative;
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    box-sizing: border-box;
    background-color: rgba(0, 0, 0, 0.15);
    border-radius: 1000rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.5);
    color: #FFFFFF;
    font-size: 32rpx;
    
    .icon {
      display: block;
      flex: 1;
      margin: auto;
      text-align: center;
    }
    
  }
  
  .oa-content{
    max-width: 640px;
    margin: 0 auto;
    background-color: #F8F7F8;
    min-height: 100vh;
    padding-bottom: 60rpx;
    padding-bottom: calc(80rpx + env(safe-area-inset-bottom) / 2);
    padding-bottom: calc(80rpx + constant(safe-area-inset-bottom));
  }

</style>
