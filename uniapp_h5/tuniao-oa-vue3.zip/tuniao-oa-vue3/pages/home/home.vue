<template>
	<view class="template-home tn-safe-area-inset-bottom">
    <!-- 顶部自定义导航 -->
    <tn-navbar fixed :bottomShadow="false" bg-color="#FFFFFF00" backText="" backIcon="" homeIcon="" >
      <template v-slot:back>
        <view class="custom-nav tn-flex tn-flex-col-center tn-flex-row-left">
          <view class="custom-nav__back">
            <tn-icon name="search-menu" @click="tn('/homePages/search')"></tn-icon>
            <tn-icon name="discover" class="tn-padding-left" @click="tn('/minePages/navigation')"></tn-icon>
          </view>
        </view>
      </template>
    </tn-navbar>
    
    <!-- 方式1 start-->
    <view class="tn-flex home-fixed" :style="{paddingTop: vuex_custom_bar_height + 'px'}">
      <view class="tn-flex-1 tn-padding-sm tn-margin-xs tn-radius" @click="tn('/momentPages/message')">
        <view class="tn-flex tn-flex-direction-column tn-flex-row-center tn-flex-col-center">
          <view class="icon1__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-bg-white tn-color-black">
            <tn-icon name="topics-fill"></tn-icon>
          </view>  
          <view class="tn-color-gray--dark tn-text-center">
            <text class="tn-text-ellipsis">互动</text>
          </view>
        </view>
      </view>
      <view class="tn-flex-1 tn-padding-sm tn-margin-xs tn-radius" @click="tn('/homePages/pending')">
        <view class="tn-flex tn-flex-direction-column tn-flex-row-center tn-flex-col-center">
          <view class="icon1__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-bg-white tn-color-black">
            <tn-icon name="flag-fill"></tn-icon>
          </view>  
          <view class="tn-color-gray--dark tn-text-center">
            <text class="tn-text-ellipsis">待办</text>
          </view>
        </view>
      </view>
      <view class="tn-flex-1 tn-padding-sm tn-margin-xs tn-radius" @click="tn('/homePages/approval')">
        <view class="tn-flex tn-flex-direction-column tn-flex-row-center tn-flex-col-center">
          <view class="icon1__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-bg-white tn-color-black">
             <tn-icon name="seal"></tn-icon>
          </view>  
          <view class="tn-color-gray--dark tn-text-center">
            <text class="tn-text-ellipsis">审批</text>
          </view>
        </view>
      </view>
      <view class="tn-flex-1 tn-padding-sm tn-margin-xs tn-radius" @click="tn('/homePages/notice')">
        <view class="tn-flex tn-flex-direction-column tn-flex-row-center tn-flex-col-center">
          <view class="icon1__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-bg-white tn-color-black">
           
            <tn-badge value="99" type="danger">
                  <tn-icon name="notice-fill">
             </tn-icon>
              </tn-badge>
          </view>  
          <view class="tn-color-gray--dark tn-text-center">
            <text class="tn-text-ellipsis">系统</text>
          </view>
        </view>
      </view>
    </view>
    <!-- 方式1 end-->
    
    <view class="tn-margin-top-sm" :style="{paddingTop: vuex_custom_bar_height +'px'}" style="max-width: 640px; margin: 0 auto;">
      <view class="">
        <view class="tn-flex tn-flex-col-center" style="margin: 50rpx 30rpx;" @click="tn('/homePages/application')">
          <view class="">
            <view class="icon15__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-color-white" style="background-color: #4B98FE;">
              <tn-icon name="menu-fill"></tn-icon>
            </view>
          </view>
          <view class="tn-padding-left-sm" style="width: 67vw">
            <view class="tn-flex tn-flex-row-between tn-flex-col-between">
              <view class="justify-content-item">
                <text class="color-tnoa tn-text-lg tn-text-bold">应用消息</text>
              </view>
            </view>
            <view class="tn-padding-top-xs tn-text-ellipsis">
              <text class="tn-color-gray">下班时间到了，勿浪费公司水电，请滚</text>
            </view>
          </view>
          <view class="" style="width: 15vw;display: flex;flex-flow: column;align-items: flex-end;">
            <view class="tn-flex tn-flex-row-right tn-margin-bottom-xs tn-margin-top-xs">
              <text class="tn-color-gray tn-text-sm">18:06</text>
            </view>
             <view class="message-dot tn-margin-top-xs">2</view>
          </view>
        </view>
        
        <view class="tn-flex tn-flex-col-center" style="margin: 50rpx 30rpx;" @click="tn('/homePages/article')">
          <view class="">
            <view class="icon15__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-color-white" style="background-color: #FFAC00;">
              <tn-icon name="image-text-fill"></tn-icon>
            </view>
          </view>
          <view class="tn-padding-left-sm" style="width: 67vw">
            <view class="tn-flex tn-flex-row-between tn-flex-col-between">
              <view class="justify-content-item">
                <text class="color-tnoa tn-text-lg tn-text-bold">行业资讯</text>
              </view>
            </view>
            <view class="tn-padding-top-xs tn-text-ellipsis">
              <text class="tn-color-gray">熟读《2023年劳动合同法》</text>
            </view>
          </view>
         <view class="" style="width: 15vw;display: flex;flex-flow: column;align-items: flex-end;">
            <view class="tn-flex tn-flex-row-right tn-margin-bottom-xs tn-margin-top-xs">
              <text class="tn-color-gray tn-text-sm">12:06</text>
            </view>
             <view class="message-dot tn-margin-top-xs">2</view>
          </view>
        </view>
        
        <view class="tn-flex tn-flex-col-center" style="margin: 50rpx 30rpx;" @click="tn('/homePages/approval')">
          <view class="">
            <view class="icon15__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-color-white" style="background-color: #00C8B0;">
              <tn-icon name="ticket-fill"></tn-icon>
            </view>
          </view>
          <view class="tn-padding-left-sm" style="width: 67vw">
            <view class="tn-flex tn-flex-row-between tn-flex-col-between">
              <view class="justify-content-item">
                <text class="color-tnoa tn-text-lg tn-text-bold">审批通知</text>
              </view>
            </view>
            <view class="tn-padding-top-xs tn-text-ellipsis">
              <text class="tn-color-gray">你的设备费用报销已通过审批</text>
            </view>
          </view>
          <view class="" style="width: 15vw;display: flex;flex-flow: column;align-items: flex-end;">
            <view class="tn-flex tn-flex-row-right tn-margin-bottom-xs tn-margin-top-xs">
              <text class="tn-color-gray tn-text-sm">08:06</text>
            </view>
            <view class="message-dot tn-margin-top-xs">2</view>
          </view>
        </view>
        
        <view class="tn-flex tn-flex-col-center" style="margin: 50rpx 30rpx;" @click="tn('/homePages/chat')">
          <view class="">
            <view class="icon15__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-color-white" style="background-color: #4B98FE;">
              <tn-icon name="my-simple-fill"></tn-icon>
            </view>
          </view>
          <view class="tn-padding-left-sm" style="width: 67vw">
            <view class="tn-flex tn-flex-row-between tn-flex-col-between">
              <view class="justify-content-item">
                <text class="color-tnoa tn-text-lg tn-text-bold">蔡东东</text>
              </view>
            </view>
            <view class="tn-padding-top-xs tn-text-ellipsis">
              <text class="tn-color-gray">麻烦帮我抓住那只猪</text>
            </view>
          </view>
          <view class="" style="width: 15vw;">
            <view class="tn-flex tn-flex-row-right tn-margin-bottom-xs tn-margin-top-xs">
              <text class="tn-color-gray tn-text-sm">10:68</text>
            </view>
            <view class="tn-flex tn-flex-row-right tn-margin-top-xs">
              <!-- <tn-badge backgroundColor="#EA5E55" fontColor="tn-color-white" :radius="30" margin="10rpx 0rpx 10rpx 10rpx"><text>6</text></tn-badge> -->
            </view>
          </view>
        </view>
        
        
        
        <view class="tn-flex tn-flex-col-center" style="margin: 50rpx 30rpx;" v-for="(item,index) in 12" :key="index" @click="tn('/homePages/chat')">
          <view class="">
            <view class="logo-pic">
              <view class="logo-image">
                <view class="" style="background-image:url('https://resource.tuniaokj.com/images/simple/image2.jpg');width: 90rpx;height: 90rpx;background-size: cover;">
                </view>
              </view>
            </view>
          </view>
          <view class="tn-padding-left-sm" style="width: 67vw">
            <view class="tn-flex tn-flex-row-between tn-flex-col-between">
              <view class="justify-content-item">
                <text class="color-tnoa tn-text-lg tn-text-bold">那只猪</text>
              </view>
              
            </view>
            <view class="tn-padding-top-xs tn-text-ellipsis">
              <text class="tn-color-gray">我不喜欢下雨，因为雨滴从不滴落我手心上；晚风轻踩着云朵，月亮在贩售快乐</text>
            </view>
          </view>
          <view class="" style="width: 15vw;">
            <view class="tn-flex tn-flex-row-right tn-margin-bottom-xs tn-margin-top-xs">
              <text class="tn-color-gray tn-text-sm">5月20日</text>
            </view>
            <view class="tn-flex tn-flex-row-right tn-margin-top-xs">
              <!-- <tn-badge backgroundColor="#EA5E55" fontColor="tn-color-white" :radius="30" margin="10rpx 0rpx 10rpx 10rpx"><text>6</text></tn-badge> -->
            </view>
          </view>
        </view>
        
      </view>
  
    </view>
    
    <view class="tn-tabbar-height"></view>
    
	</view>
</template>

<script setup>
  import { ref,computed } from 'vue'
   import { useStore } from 'vuex'
  
  const store = useStore()
    // 使用 computed 保持响应式
  const vuex_custom_bar_height = computed(() => store.state.vuex_custom_bar_height)
  
  // 可以在这里定义响应式数据
  // const someData = ref('')
  
  // 跳转方法
  const tn = (e) => {
    uni.navigateTo({
      url: e,
    })
  }
</script>

<style lang="scss" scoped>
	.template-home{
	  max-height: 100vh;
    max-width: 640px; 
    margin: 0 auto;
	}
  
  /* 自定义导航栏内容 start */
  .custom-nav {
    max-width: 640px; 
    height: 100%;
    
    &__back {
      margin: auto 5rpx;
      font-size: 45rpx;
      margin-right: 10rpx;
      margin-left: 30rpx;
    }
  }
  /* 自定义导航栏内容 end */
  
  /* 新增OA色系，自行调用，或者拿色值去用，多种方式*/
  .oa-black{
    color: #1D2541;
  }
  .oa-blue{
    color: #4B98FE;
  }
  .oa-orangeyellow{
    color: #FFAC00;
  }
  .oa-green{
    color: #00D05E;
  }
  .oa-orange{
    color: #FE871B;
  }
  .oa-cyan{
    color: #00C8B0;
  }
  .oa-indigo{
    color: #00B9FE;
  }
  .oa-orangered{
    color: #FB6A67;
  }
  .oa-purple{
    color: #957BFE;
  }
  
  /* 底部安全边距 start*/
  .tn-tabbar-height {
  	min-height: 120rpx;
  	height: calc(140rpx + env(safe-area-inset-bottom));
  	height: calc(140rpx + constant(safe-area-inset-bottom));
  }
  
  
  // 四个角渐变底色
  .home-fixed{
    max-width: 640px; 
    position: fixed;
    background: linear-gradient(90deg, #DBF2FE, #FFE1E1);
    top: 0;
    width: 100%;
    transition: all 0.25s ease-out;
    z-index: 100;
  }
  .home-fixed:before{
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    z-index: -1;
    mask-image: linear-gradient(to bottom, transparent, black);
    background: linear-gradient(90deg, #FFFFFF, #FFFFFF);	

  }
  
  /* OA黑色*/
  .color-tnoa{
    color: #1D2541;
  }
  
  /* 页面阴影 start*/
  .oa-shadow {
    border-radius: 15rpx;
    box-shadow: 0rpx 0rpx 50rpx 0rpx rgba(0, 0, 0, 0.07);
  }
  
  
 
  
  /* 图标容器1 start */
  .icon1 {
    &__item {
      width: 30%;
      background-color: #FFFFFF;
      border-radius: 10rpx;
      padding: 30rpx;
      margin: 20rpx 10rpx;
      transform: scale(1);
      transition: transform 0.3s linear;
      transform-origin: center center;
      
      &--icon {
        width: 100rpx;
        height: 100rpx;
        font-size: 60rpx;
        border-radius: 50%;
        margin-bottom: 18rpx;
        position: relative;
        z-index: 1;
        
        &::after {
          content: " ";
          position: absolute;
          z-index: -1;
          width: 100%;
          height: 100%;
          left: 0;
          bottom: 0;
          border-radius: inherit;
          opacity: 1;
          transform: scale(1, 1);
          background-size: 100% 100%;
          background-image: url(https://resource.tuniaokj.com/images/cool_bg_image/icon_bg5.png);
        }
      }
    }
  }
  
  /* 图标容器15 start */
  .icon15 {
    &__item {
      width: 30%;
      background-color: #FFFFFF;
      padding: 30rpx;
      margin: 20rpx 10rpx;
      transform: scale(1);
      transition: transform 0.3s linear;
      transform-origin: center center;
      
      &--icon {
        width: 90rpx;
        height: 90rpx;
        font-size: 60rpx;
        border-radius: 50%;
        position: relative;
        z-index: 1;
        
        &::after {
          content: " ";
          position: absolute;
          z-index: -1;
          width: 100%;
          height: 100%;
          left: 0;
          bottom: 0;
          border-radius: inherit;
          opacity: 1;
          transform: scale(1, 1);
          background-size: 100% 100%;
  
            
        }
      }
    }
  }
  
  /* 用户头像 start */
  .logo-image {
    width: 90rpx;
    height: 90rpx;
    position: relative;
  }
  
  .logo-pic {
    background-size: cover;
    background-repeat: no-repeat;
    // background-attachment:fixed;
    background-position: center;
    // border: 1rpx solid rgba(255,255,255,0.05);
    // box-shadow: 0rpx 0rpx 80rpx 0rpx rgba(0, 0, 0, 0.15);
    border-radius: 50%;
    overflow: hidden;
    // background-color: #FFFFFF;
  }
  
</style>
