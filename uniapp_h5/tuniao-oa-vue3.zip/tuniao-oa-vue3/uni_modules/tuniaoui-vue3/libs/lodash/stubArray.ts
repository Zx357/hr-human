export function stubArray() {
  return []
}
