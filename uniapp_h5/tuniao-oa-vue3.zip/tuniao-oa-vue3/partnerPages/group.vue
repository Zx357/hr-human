<template>
  <view class="oa-content">
    <!-- 顶部自定义导航 -->
    <tn-navbar fixed home-icon="" :bottom-shadow="false" bg-color="#FFFFFF" :placeholder="false">
      <view slot="back" class='tn-custom-nav-bar__back'
        @click="goBack">
        <tn-icon name="left-arrow" class="icon"></tn-icon>
      </view>
      <view class="tn-flex tn-flex-col-center tn-flex-row-center ">
        <text class="tn-text-bold tn-text-xl tn-color-black">我的群聊</text>
      </view>
    </tn-navbar>
    
    
    <view class="" :style="{paddingTop: vuex_custom_bar_height + 10 + 'px'}">
      <view class="tn-flex tn-flex-col-center" style="margin: 50rpx 0rpx 50rpx 30rpx;" v-for="(item,index) in 12" :key="index">
        <!-- <view class="icon15__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-bg-blue--light tn-color-blue">
          <tn-icon name="organizatio-fill"></tn-icon>
        </view> -->
        <view class="logo-pic">
          <view class="logo-image" style="background-image:url('https://cdn.nlark.com/yuque/0/2023/jpeg/280373/1692940242409-assets/web-upload/fcc4eab6-b2ce-44eb-9165-c49b51f5f830.jpeg');width: 90rpx;height: 90rpx;background-size: cover;">
          </view>
        </view>
        <view class="tn-padding-left-sm" style="width: 67vw">
          <view class="tn-flex tn-flex-row-between tn-flex-col-between">
            <view class="justify-content-item">
              <text class="oa-black tn-text-xl">图鸟UI交流群</text>
            </view>
            
          </view>
          <view class="tn-padding-top-xs tn-text-ellipsis">
            <text class="tn-color-gray tn-text-sm">最近消息 16:30</text>
          </view>
        </view>
        <view class="" style="width: 15vw;">
          <text class="tn-color-gray tn-padding-right-xs">29人</text>
          <tn-icon name="right" class="tn-color-gray tn-text-lg"></tn-icon>
        </view>
      </view>
      
    </view>
    
    <view class='tn-tabbar-height'></view>
    
  </view>
</template>

<script setup>
  import { useCustomBarHeight, useGoBack } from '@/libs/composables'
  // 使用 composable 获取自定义导航栏高度
  const { vuex_custom_bar_height } = useCustomBarHeight()
  const { goBack } = useGoBack()
  
  // 跳转
  const tn = (e) => {
    uni.navigateTo({
      url: e,
    });
  }
</script>

<style lang="scss" scoped>
  /* 胶囊*/
  .tn-custom-nav-bar__back {
    width: 60%;
    height: 100%;
    position: relative;
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    box-sizing: border-box;
    background-color: rgba(0, 0, 0, 0.15);
    border-radius: 1000rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.5);
    color: #FFFFFF;
    font-size: 18px;
    
    .icon {
      display: block;
      flex: 1;
      margin: auto;
      text-align: center;
    }
    
  }
  
  .oa-content{
    max-width: 640px;
    margin: 0 auto;
    // background-color: #F8F7F8;
    min-height: 100vh;
    padding-bottom: 60rpx;
    padding-bottom: calc(80rpx + env(safe-area-inset-bottom) / 2);
    padding-bottom: calc(80rpx + constant(safe-area-inset-bottom));
  }
  
  /* 底部安全边距 start*/
  .tn-tabbar-height {
  	min-height: 60rpx;
  	height: calc(80rpx + env(safe-area-inset-bottom));
  	height: calc(80rpx + constant(safe-area-inset-bottom));
  }
  
  
  /* 新增OA色系，自行调用，或者拿色值去用，多种方式*/
  .oa-black{
    color: #1D2541;
    // background-color: #1D254150;
  }
  .oa-blue{
    color: #4B98FE;
    background-color: #4B98FE50;
  }
  .oa-orangeyellow{
    color: #FFAC00;
    background-color: #FFAC0050;
  }
  .oa-green{
    color: #00D05E;
    background-color: #00D05E50;
  }
  .oa-orange{
    color: #FE871B;
    background-color: #FE871B50;
  }
  .oa-cyan{
    color: #00C8B0;
    background-color: #00C8B050;
  }
  .oa-indigo{
    color: #00B9FE;
    background-color: #00B9FE50;
  }
  .oa-orangered{
    color: #FB6A67;
    background-color: #FB6A6750;
  }
  .oa-purple{
    color: #957BFE;
    background-color: #957BFE50;
  }
  
  /* 图标容器15 start */
  .icon15 {
    &__item {
      width: 30%;
      background-color: #FFFFFF;
      padding: 30rpx;
      margin: 20rpx 10rpx;
      transform: scale(1);
      transition: transform 0.3s linear;
      transform-origin: center center;
      
      &--icon {
        width: 90rpx;
        height: 90rpx;
        font-size: 60rpx;
        border-radius: 20rpx;
        position: relative;
        z-index: 1;
        
        &::after {
          content: " ";
          position: absolute;
          z-index: -1;
          width: 100%;
          height: 100%;
          left: 0;
          bottom: 0;
          border-radius: inherit;
          opacity: 1;
          transform: scale(1, 1);
          background-size: 100% 100%;
  
            
        }
      }
    }
  }

  /* 用户头像 start */
  .logo-image {
    width: 90rpx;
    height: 90rpx;
    position: relative;
  }
  
  .logo-pic {
    background-size: cover;
    background-repeat: no-repeat;
    // background-attachment:fixed;
    background-position: center;
    // border: 1rpx solid rgba(255,255,255,0.05);
    // box-shadow: 0rpx 0rpx 80rpx 0rpx rgba(0, 0, 0, 0.15);
    border-radius: 20rpx;
    overflow: hidden;
    // background-color: #FFFFFF;
  }
</style>
