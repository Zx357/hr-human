<template>
  <view class="">
    <web-view src="https://mp.weixin.qq.com/s/HvduVSi6vVcwK74tmoz1zw"></web-view>
    <!-- <web-view src="https://mp.weixin.qq.com/s/1apBuGcPQXMfz2osv5wwiQ"></web-view> -->
  </view>
</template>

<script setup>
</script>

<style lang="scss" scoped>
  
</style>
