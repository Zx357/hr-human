<template>
  <view class="oa-content">
    <!-- 顶部自定义导航 -->
    <tn-navbar fixed home-icon="" :bottom-shadow="false" bg-color="#FFFFFF" :placeholder="false">
      <view slot="back" class='tn-custom-nav-bar__back'
        @click="goBack">
        <tn-icon class='icon' name="left-arrow"></tn-icon>
      </view>
      <view class="tn-flex tn-flex-col-center tn-flex-row-center ">
        <text class="tn-text-bold tn-text-xl tn-color-black">文件助手</text>
      </view>
    </tn-navbar>
    
    
    <view class="tn-text-center" :style="{paddingTop: vuex_custom_bar_height + 10 + 'px'}">
      
      <view class="tn-margin file-radius" :class="['oa-' + item.color]" v-for="(item, index) in fileList" :key="index">
        <view class="tn-flex tn-flex-row-between tn-padding">
          <view class="justify-content-item tn-text-bold tn-text-left" style="width: 80%;">
            {{ item.title }}
          </view>
          <view class="justify-content-item">
            <text class="tn-padding-right-xs">{{ item.download }}</text>
            <tn-icon name="send"></tn-icon>
          </view>
        </view>
        <view class="tn-flex tn-flex-row-between tn-padding-left tn-padding-right tn-padding-bottom">
          <view class="justify-content-item tn-margin-right">
            <view class="tn-flex tn-flex-col-center tn-flex-row-left">
              <!-- <view class="logo-pic">
                <view class="logo-image" :style="'background-image:url('+ item.userImage +');width: 30rpx;height: 30rpx;background-size: cover;'">
                </view>
              </view> -->
              <tn-icon class="tn-padding-right-xs" name="folder-fill"></tn-icon>
              <view class="">{{ item.size }}</view>
            </view>
          </view>
          <view class="justify-content-item">
            <text class="">{{ item.date }}</text>
          </view>
        </view>
      </view>
      
      
      <view class="">
        <view class="icon15__item--icon tn-flex tn-flex-row-center tn-flex-col-center tn-shadow-blur button-1" @click="tn('/minePages/upload')">
          <tn-icon class="tn-color-white" name="edit-write"></tn-icon>
        </view>
      </view>  

      
    </view>
    
    <view class='tn-tabbar-height'></view>
    
  </view>
</template>

<script setup>
  import { ref } from 'vue'
  import { useCustomBarHeight, useGoBack } from '@/libs/composables'
  // 使用 composable 获取自定义导航栏高度
  const { vuex_custom_bar_height } = useCustomBarHeight()
  const { goBack } = useGoBack()
  
  const fileList = ref([{
    color: 'green',
    title: '图鸟分公司年终活动报名表.xls',
    size: '12.68 KB',
    download: '106',
    userImage: 'https://resource.tuniaokj.com/images/blogger/avatar_3.jpeg',
    userName: '抓住那只猪',
    date: '12月20日',
  }, {
    color: 'orange',
    title: '图鸟技术峰会-编程挑战赛资料.zip',
    size: '8.22 MB',
    download: '129',
    userImage: 'https://resource.tuniaokj.com/images/blogger/avatar_2.jpeg',
    userName: '你的名字',
    date: '10月18日',
  }, {
    color: 'orangered',
    title: '图鸟科技-规章制度.pdf',
    size: '806.23 KB',
    download: '602',
    userImage: 'https://resource.tuniaokj.com/images/blogger/avatar_1.jpeg',
    userName: '不许凶我吖',
    date: '10月09日',
  }, {
    color: 'blue',
    title: '图鸟logo视频动画.mp4',
    size: '12 MB',
    download: '53',
    userImage: 'https://resource.tuniaokj.com/images/blogger/avatar_2.jpeg',
    userName: '图鸟西西',
    date: '08月26日',
  }, {
    color: 'green',
    title: '物料打印.xls',
    size: '16.33 KB',
    download: '38',
    userImage: 'https://resource.tuniaokj.com/images/blogger/avatar_3.jpeg',
    userName: '抓住那只猪',
    date: '07月22日',
  }, {
    color: 'orangeyellow',
    title: '中秋宣传资料.ppt',
    size: '2.03 MB',
    download: '66',
    userImage: 'https://resource.tuniaokj.com/images/blogger/avatar_4.jpeg',
    userName: '你的名字',
    date: '07月06日',
  }, {
    color: 'cyan',
    title: '猛犸空间服务有限公司-开票资料.doc',
    size: '28 KB',
    download: '258',
    userImage: 'https://resource.tuniaokj.com/images/blogger/avatar_3.jpeg',
    userName: '图鸟猪猪',
    date: '04月22日',
  }, {
    color: 'purple',
    title: '凶姐表情包.gif',
    size: '69 KB',
    download: '34',
    userImage: 'https://resource.tuniaokj.com/images/blogger/avatar_2.jpeg',
    userName: '你的名字',
    date: '02月28日',
  }, {
    color: 'indigo',
    title: '广告海报.jpg',
    size: '503 KB',
    download: '32',
    userImage: 'https://resource.tuniaokj.com/images/blogger/avatar_1.jpeg',
    userName: '你的名字',
    date: '02月20日',
  }])
  
  // 跳转
  function tn(e) {
    uni.navigateTo({
      url: e,
    });
  }
</script>

<style lang="scss" scoped>
  /* 胶囊*/
  .tn-custom-nav-bar__back {
    width: 60%;
    height: 100%;
    position: relative;
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    box-sizing: border-box;
    background-color: rgba(0, 0, 0, 0.15);
    border-radius: 1000rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.5);
    color: #FFFFFF;
    font-size: 18px;
    
    .icon {
      display: block;
      flex: 1;
      margin: auto;
      text-align: center;
    }
    
  }
  .oa-content{
    max-width: 640px;
    margin: 0 auto;
    // background-color: #F8F7F8;
    min-height: 100vh;
    padding-bottom: 60rpx;
    padding-bottom: calc(80rpx + env(safe-area-inset-bottom) / 2);
    padding-bottom: calc(80rpx + constant(safe-area-inset-bottom));
  }
  
  /* 底部安全边距 start*/
  .tn-tabbar-height {
  	min-height: 60rpx;
  	height: calc(80rpx + env(safe-area-inset-bottom));
  	height: calc(80rpx + constant(safe-area-inset-bottom));
  }
  
  
  /* 新增OA色系，自行调用，或者拿色值去用，多种方式*/
  .oa-black{
    color: #1D2541;
    background-color: #1D254150;
  }
  .oa-blue{
    color: #4B98FE;
    background-color: #4B98FE50;
  }
  .oa-orangeyellow{
    color: #FFAC00;
    background-color: #FFAC0050;
  }
  .oa-green{
    color: #00D05E;
    background-color: #00D05E50;
  }
  .oa-orange{
    color: #FE871B;
    background-color: #FE871B50;
  }
  .oa-cyan{
    color: #00C8B0;
    background-color: #00C8B050;
  }
  .oa-indigo{
    color: #00B9FE;
    background-color: #00B9FE50;
  }
  .oa-orangered{
    color: #FB6A67;
    background-color: #FB6A6750;
  }
  .oa-purple{
    color: #957BFE;
    background-color: #957BFE50;
  }
  
  .file-radius{
    border-radius: 10rpx;
  }
  
  /* 用户头像 start */
  .logo-image {
    width: 30rpx;
    height: 30rpx;
    position: relative;
  }
  
  .logo-pic {
    background-size: cover;
    background-repeat: no-repeat;
    // background-attachment:fixed;
    background-position: top;
    border: 1rpx solid rgba(255,255,255,0.05);
    // box-shadow: 0rpx 0rpx 80rpx 0rpx rgba(0, 0, 0, 0.15);
    border-radius: 50%;
    overflow: hidden;
    // background-color: #FFFFFF;
  }
  
  /* 按钮 */
  .button-1 {
    // background-color: rgba(0, 0, 0, 0.15);
    background-color: #3668FC80;
    position: fixed;
    /* bottom:200rpx;
      right: 20rpx; */
    bottom: 15%;
    right: 30rpx;
    z-index: 1001;
    border-radius: 100px;
  }
  
  /* 图标容器15 start */
  .icon15 {
    &__item {
      width: 30%;
      
      border-radius: 10rpx;
      padding: 30rpx;
      margin: 20rpx 10rpx;
      transform: scale(1);
      transition: transform 0.3s linear;
      transform-origin: center center;
      
      &--icon {
        width: 90rpx;
        height: 90rpx;
        font-size: 50rpx;
        border-radius: 50%;
        margin-bottom: 18rpx;
        z-index: 1;
        
        &::after {
          content: " ";
          position: absolute;
          z-index: -1;
          width: 100%;
          height: 100%;
          left: 0;
          bottom: 0;
          border-radius: inherit;
          opacity: 1;
          transform: scale(1, 1);
          background-size: 100% 100%;
        }
      }
    }
  }
</style>
