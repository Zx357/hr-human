<template>
  <view class="oa-content">
    <!-- 顶部自定义导航 -->
    <tn-navbar fixed :placeholder="false" bg-color="#ffffff00" customBack>
      <view slot="back" class='tn-custom-nav-bar__back'
        @click="goBack">
        <tn-icon class='icon' name='left'></tn-icon>
        <tn-icon class='icon' name='home-capsule-fill'></tn-icon>
      </view>
    </tn-navbar>
    
    
    <view class="" :style="{paddingTop: vuex_custom_bar_height + 60 + 'px'}">
      
      <view class="dd-button tn-text-center">
        <view class="" style="padding-top: 85rpx;">
          补 卡
        </view>
      </view>
      
    </view>
  </view>
</template>

<script setup>
import { useCustomBarHeight, useGoBack } from '@/libs/composables'
// 使用 composable 获取自定义导航栏高度
const { vuex_custom_bar_height } = useCustomBarHeight()
const { goBack } = useGoBack()
</script>

<script>
export default {
  name: 'TemplateReplace',
  
}
</script>

<style lang="scss" scoped>
  /* 胶囊*/
  .tn-custom-nav-bar__back {
    width: 100%;
    height: 100%;
    position: relative;
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    box-sizing: border-box;
    background-color: rgba(0, 0, 0, 0.15);
    border-radius: 1000rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.5);
    color: #FFFFFF;
    font-size: 18px;
    
    .icon {
      display: block;
      flex: 1;
      margin: auto;
      text-align: center;
    }
    
    &:before {
      content: " ";
      width: 1rpx;
      height: 110%;
      position: absolute;
      top: 22.5%;
      left: 0;
      right: 0;
      margin: auto;
      transform: scale(0.5);
      transform-origin: 0 0;
      pointer-events: none;
      box-sizing: border-box;
      opacity: 0.7;
      background-color: #FFFFFF;
    }
  }
  
  .oa-content{
    max-width: 640px;
    margin: 0 auto;
    // background-color: #F8F7F8;
    min-height: 100vh;
    padding-bottom: 60rpx;
    padding-bottom: calc(80rpx + env(safe-area-inset-bottom) / 2);
    padding-bottom: calc(80rpx + constant(safe-area-inset-bottom));
  }
  
  .dd-button {
    display: block;
    width: 200rpx;
    height: 200rpx;
    margin: 300rpx auto;
    animation: ripple 0.6s linear infinite;
    border-radius: 50px;
    background-color: #FFFFFF;
  }
  
  @keyframes ripple {
    0% {
      box-shadow: 0 0 0 0 rgba(54, 104, 252, 0.1), 0 0 0 20px rgba(54, 104, 252, 0.1), 0 0 0 40px rgba(54, 104, 252, 0.1), 0 0 0 60px rgba(54, 104, 252, 0.1);
    }
    100% {
      box-shadow: 0 0 0 20px rgba(54, 104, 252, 0.1), 0 0 0 40px rgba(54, 104, 252, 0.1), 0 0 0 60px rgba(54, 104, 252, 0.1), 0 0 0 80px rgba(54, 104, 252, 0);
    }
  }

  
  
</style>
